//import update from './update.js';

// even though Rollup is bundling all your files together, errors and
// logs will still point to your original source modules
//console.log('if you have sourcemaps enabled in your devtools, click on main.js:5 -->');

import game from './game.js';

game();

//update();
